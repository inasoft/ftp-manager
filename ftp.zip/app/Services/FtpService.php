<?php

// app/Services/FtpService.php

namespace App\Services;

class FtpService
{
    public function connect($host, $username, $password, $port)
    {
        $ftp_conn = ftp_connect($host, $port) or die("Could not connect to $host");

        if (ftp_login($ftp_conn, $username, $password)) {
            return $ftp_conn; // Return the FTP connection resource
        } else {
            throw new \Exception('FTP login failed');
        }
    }

    public function listFiles($ftpConn, $directory = '/')
    {
        $files = ftp_nlist($ftpConn, $directory);
        return $files;
    }
}



?>