<?php 
namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use App\Services\FtpService;
use Illuminate\Http\Request;
use App\Http\Requests\FtpConnectionRequest; 


class FtpController extends Controller
{

	public function index(Request $request, FtpService $ftp)
	{
	    $request->validate([
	        'host' => 'required',
	        'username' => 'required|string',
	        'password' => 'required',
	        'port' => 'required|integer',
	    ]);

	    $host = $request->input('host');
	    $username = $request->input('username');
	    $password = $request->input('password');
	    $port = $request->input('port');

	    try {
	        // Connect to the FTP server
	        $ftp->connect($host, $username, $password, $port);

	        // List files in the root directory (you can specify a different directory)
	        $files = $ftp->listFiles();

	        return view('ftp.index', ['files' => $files]);
	    } catch (\Exception $e) {
	        return view('ftp.error', ['error' => $e->getMessage()]);
	    }
	}

}



?>