@extends('layouts.app')  

@section('content')
<div class="container">
<form method="POST" action="{{ route('connect.host') }}">
    @csrf
    <div class="form-group">
        <label for="host">Host:</label>
        <input type="text" name="host" id="host" class="form-control" required>
        @error('host')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div>
    <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" class="form-control" required>
        @error('username')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" class="form-control" required>
        @error('password')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div>
    <div class="form-group">
        <label for="port">Port:</label>
        <input type="number" name="port" id="port" class="form-control" required>
        @error('port')
            <span class="text-danger">{{ $message }}</span>
        @enderror
    </div></br>
    <button type="submit" class="btn btn-primary">Connect</button>
</form>
</div>
@endsection
