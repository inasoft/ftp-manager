<!DOCTYPE html>
<html>
<head>
    <title>Error Page</title>
</head>
<body>
    <div>
        <h1>Error Page</h1>
        <pre>
            {{ ($error) }}
        </pre>
    </div>
</body>
</html>
