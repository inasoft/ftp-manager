<!DOCTYPE html>
<html>
<head>
    <title>Error Page</title>
</head>
<body>
    <div>
        <h1>Error Page</h1>
        <pre>
            <?php echo e(($error)); ?>

        </pre>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ftp-file-manager\resources\views/ftp/error.blade.php ENDPATH**/ ?>