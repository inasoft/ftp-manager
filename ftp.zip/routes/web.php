<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\HostController;
use App\Http\Controllers\FtpController;


Route::get('/', function () {
    return view('welcome');
});


Route::get('/connect', [HostController::class, 'showForm'])->name('connect.form');


Route::post('/connecthost', [FtpController::class, 'index'])->name('connect.host');


//Route::get('/connect', 'HostController@showForm')->name('connect.form');

//Route::post('/connect', 'FileController@listFiles')->name('file.list');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
